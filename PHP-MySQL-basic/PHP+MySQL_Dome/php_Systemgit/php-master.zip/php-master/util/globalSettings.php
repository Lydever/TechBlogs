<?php 

define('IMAGE_URL', 'http://192.168.7.100:9999/1031/images/');

define('PARAM_INVALID' , '参数无效');

define('SESSION_KEY_CURRENT_USER' , 'CurrentUser');
define('SESSION_KEY_REFERER_URL' , 'RefererUrl');
define('SESSION_KEY_MESSAGE' , 'Message');


/**
 * [checkPhone description]
 * @param  [type] $input [description]
 * @return [type]        [description]
 */
function checkPhone($input){
	return false;
}