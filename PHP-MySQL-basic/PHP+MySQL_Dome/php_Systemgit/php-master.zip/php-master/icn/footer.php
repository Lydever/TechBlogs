<!-- <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>footer</title>
	<link rel="stylesheet" type="text/css" href="css/footer.css">
</head>
<body> -->
	<div class="footer">
		<div>
			<p>全力做好网上治安秩序打击整治专项行动，打造晴朗网络空间</p>
			<p>网站地图 | 联系我们 | 广告服务 | 诚聘英才 | 用户服务协议 | 隐私政策 | 有书看网站免责声明 | 有书看网站著作保护声明 | 未成年人家长监护工程</p>
			<p>扬州有书看科技有限公司版权所有</p>
		</div>
	</div>
<!-- </body>
</html> -->